<?php
// Update these settings for your hosting account.
define('DB_HOST', 'localhost');
define('DB_NAME', 'linguafree');
define('DB_USER', 'root');
define('DB_PASS', '');
define('SITE_NAME', 'LinguaFree');
session_start();
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
    }
    return $pdo;
}
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function logged_in(): bool { return !empty($_SESSION['user']); }
function require_login(): void { if (!logged_in()) { header('Location: login.php'); exit; } }
function is_admin(): bool { return logged_in() && ($_SESSION['user']['role'] ?? '') === 'admin'; }
