<?php require_once __DIR__.'/../config.php'; ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($page_title ?? SITE_NAME) ?> | <?= SITE_NAME ?></title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="top"><a class="brand" href="index.php">Lingua<span>Free</span></a><nav>
<a href="index.php">Home</a><a href="courses.php">Courses</a>
<?php if(logged_in()): ?><a href="dashboard.php">My Learning</a><?php if(is_admin()): ?><a href="admin.php">Admin</a><?php endif; ?><a href="logout.php">Logout</a>
<?php else: ?><a href="login.php">Login</a><a class="navbtn" href="register.php">Join Free</a><?php endif; ?></nav></header><main class="wrap">
